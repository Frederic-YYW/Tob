package com.dfzz.test.enu;

public enum InterfaceNameEnum {

    TEST_A("testA"),
    TEST_B("testB");

    private String infName;

    InterfaceNameEnum(String infName) {
        this.infName = infName;
    }

    public String getInfName() {
        return infName;
    }

    public void setInfName(String infName) {
        this.infName = infName;
    }

    /**
     * description: 获取枚举类
     *
     * @param infName
     * @return cn.henry.study.common.enums.infNameEnum
     * @author Hlingoes 2020/6/10
     */
    public static InterfaceNameEnum getByInfName(String infName) {
        InterfaceNameEnum[] arr = values();
        for (InterfaceNameEnum item : arr) {
            if (null != item && item.infName.equals(infName)) {
                return item;
            }
        }
        return null;
    }
}
