package com.dfzz.test.enu;

/**
 * 每个接口的日志
 */
public enum LogInfoEnum {
    TEST_A("testA","_%d{yyyy-MM-dd HH:mm:ss}.%i","test_A",10),
    TEST_B("testB","_%d{yyyy-MM-dd HH:mm:ss}.%i","test_B",10);
    String infName;
    String pattern;
    String logName;
    int maxHistory;
    LogInfoEnum(String infName, String pattern, String logName, int maxHistory){
        this.infName=infName;
        this.logName=logName;
        this.maxHistory=maxHistory;
        this.pattern=pattern;
    }

    public String getInfName() {
        return infName;
    }

    public void setInfName(String infName) {
        this.infName = infName;
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getLogName() {
        return logName;
    }

    public void setLogName(String logName) {
        this.logName = logName;
    }

    public int getMaxHistory() {
        return maxHistory;
    }

    public void setMaxHistory(int maxHistory) {
        this.maxHistory = maxHistory;
    }

    public static LogInfoEnum getByInfName(String infName) {
        LogInfoEnum[] arr = values();
        for (LogInfoEnum item : arr) {
            if (null != item && item.infName.equals(infName)) {
                return item;
            }
        }
        return null;
    }
}
