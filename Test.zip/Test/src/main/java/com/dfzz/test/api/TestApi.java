package com.dfzz.test.api;

import com.dfzz.test.enu.InterfaceNameEnum;
import com.dfzz.test.service.TestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
@Slf4j
public class TestApi {
    @Autowired
    private TestService testService;

    @RequestMapping("/testA")
    public String testA(@RequestHeader String appId, @RequestBody String obj){
        testService.save(appId, InterfaceNameEnum.TEST_A,obj);
        return "success";
    }

    @RequestMapping("/testB")
    public String testB(@RequestHeader String appId, @RequestBody String obj){
        testService.save(appId, InterfaceNameEnum.TEST_B,obj);
        return "success";
    }
}
