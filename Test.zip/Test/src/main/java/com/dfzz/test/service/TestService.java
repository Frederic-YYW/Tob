package com.dfzz.test.service;

import com.dfzz.test.enu.InterfaceNameEnum;
import com.dfzz.test.enu.LogInfoEnum;

public interface TestService {
    boolean save(String appId, InterfaceNameEnum interfaceNameEnum, Object object);
    String getSaveFileName(String appId, LogInfoEnum infoEnum);
}
