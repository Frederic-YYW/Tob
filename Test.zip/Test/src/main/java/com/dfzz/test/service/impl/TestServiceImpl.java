package com.dfzz.test.service.impl;

import ch.qos.logback.classic.*;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy;
import ch.qos.logback.core.util.FileSize;
import ch.qos.logback.core.util.OptionHelper;
import cn.hutool.core.util.StrUtil;
import com.dfzz.test.enu.InterfaceNameEnum;
import com.dfzz.test.enu.LogInfoEnum;
import com.dfzz.test.service.TestService;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

@Service
@Slf4j
public class TestServiceImpl implements TestService {
    @Value("${log.path}")
    private String logPath;

    @Value("${independent.log.size}")
    private String logSize;

    @Value("${independent.log.quize.size}")
    private int queueSize;

    @Value("${independent.save.idList}")
    private List<String> idList;

    @Override
    public boolean save(String appId, InterfaceNameEnum interfaceNameEnum, Object object) {
        LogInfoEnum logInfoEnum=LogInfoEnum.getByInfName(interfaceNameEnum.getInfName());
        String saveFileName = getSaveFileName(appId, logInfoEnum);
        Logger logger = getLogger(saveFileName, appId, logInfoEnum);
        logger.info(object+"");
        return false;
    }

    @Override
    public String getSaveFileName(String appId, LogInfoEnum infoEnum) {
        String logName="";
        if(idList.contains(appId)){
            logName=logPath+File.separator+appId+ File.separator+infoEnum.getLogName();
        }else {
            logName=logPath+File.separator+infoEnum.getLogName();
        }
        return logName;
    }

    private Logger getLogger(String logName, String appId, LogInfoEnum logInfoEnum){
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

        ch.qos.logback.classic.Logger logger = context.getLogger(logName);
        logger.setAdditive(false);

        RollingFileAppender appender = new RollingFileAppender();
        appender.setContext(context);
        appender.setName(logName);
        String dataFolder="";

        SizeAndTimeBasedRollingPolicy policy=new SizeAndTimeBasedRollingPolicy();
        String tempPath=null;
        if(logName.contains(File.separator)){
            tempPath=logPath+File.separator+appId+File.separator+logInfoEnum.getLogName();
        }else {
            tempPath=logPath+File.separator+logInfoEnum.getLogName();
        }
        logger = context.getLogger(tempPath+".log");
        appender.setFile(OptionHelper.substVars(tempPath+".log",context));
        dataFolder=OptionHelper.substVars(tempPath+logInfoEnum.getPattern()+".log",context);
        policy.setFileNamePattern(dataFolder);
        policy.setMaxHistory(logInfoEnum.getMaxHistory());

        if(StrUtil.isNotBlank(logSize)){
            policy.setMaxFileSize(FileSize.valueOf(logSize));
        }else {
            policy.setMaxFileSize(new FileSize(300*1024*1024));
        }
        policy.setParent(appender);
        policy.setContext(context);
        policy.start();

        PatternLayoutEncoder encoder=new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setPattern("%msg%n");
        encoder.start();

        appender.setRollingPolicy(policy);
        appender.setEncoder(encoder);
        appender.start();

        AsyncAppender asyncAppender=new AsyncAppender();
        asyncAppender.setQueueSize(queueSize);
        asyncAppender.setDiscardingThreshold(0);
        asyncAppender.setContext(context);
        asyncAppender.addAppender(appender);
        asyncAppender.start();

        logger.addAppender(asyncAppender);
        logger.setLevel(Level.INFO);
        return logger;
    }
}
